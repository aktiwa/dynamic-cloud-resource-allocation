<?php


?>

<!DOCOTYPE html>
<html lang="en-US">
    <head>
        <meta charset="UTF-8">
        <title> Dynamic Resorce Allocation Using OpenStack </title>
        <link rel="stylesheet"
              type="text/css"
              href="CSS/main.css" />
    </head>

    <body>
        <div id = "head">
            <h1> Dynamic Resorce Allocation Using OpenStack </h1>
        </div>

        <div id = "left">
          
        </div>

        <div id = "center">

        </div>
	
        <div id = "right">
            <h2>Welcome</h2>
            <p class="class1">
                This website is made to launch auto-scaling algorithm
            </p>
            <p class="class2">
                All nodes are hosted in OpenStack environment
            </p>
	  <p class="class3">
                The following lines are the out-put of auto-scaling
            </p>

 <?php

 include "launching_instance_from_snapshot.php";
          ?>

<p class="class3">
                Below is the server detail given by PHP
            </p>



<?php
phpinfo();
?>

        </div>

        <div id = "footer">
          Copyright (c) 2016 Amrit Tiwary All Rights Reserved.
            <address>
                <a href = "mailto:aktiwa@essex.ac.uk">
                    aktiwa@essex.ac.uk</a>
            </address>
        </div>
    </body>
</html>
