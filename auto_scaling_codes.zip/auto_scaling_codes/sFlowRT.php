
<?php

echo 'from sFlowRT'."\r\n";
require 'auth_api.php';

//-----------------------------
// 1. List sflow metrics
//-----------------------------

if(!function_exists(get_mem_utl_host)){

function get_mem_utl_host($service, $host, $metric){
  $service = $service."/$host/$metric/json";
  //echo '<br>'.$service.'<br>';
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_VERBOSE, false);
  curl_setopt($ch, CURLOPT_URL, $service);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_HTTPHEADER, array(
  //        'X-Auth-Token: ' . $token
      )
  );
  $result = curl_exec($ch);
  $networks = json_decode($result);
  curl_close($ch);
  return $networks;
}
}
//MAIN FUNCTION

for($xd = 0; $xd < 10; $xd++)
{


$x = 0;
$server_ip_add = '30.30.1.57';
$metric = "mem_utilization";
$link1 = 'http://192.168.7.65:8008/metric';

$metrName = $metrValue = array();

$mem_utl = get_mem_utl_host($link1, $server_ip_add, $metric);


foreach($mem_utl as $singlemetr){
  $metrName[$x] = $singlemetr->metricName;
  $metrValue[$x] = $singlemetr->metricValue;
  $x++;
}

  $fd = 0;

foreach($metrName as $singlemet){
//printing metric name and its value got from sflowRT
  echo "<br>$metrName[$fd] = $metrValue[$fd]"."\r\n";
 sleep(5);
}
}
?>
