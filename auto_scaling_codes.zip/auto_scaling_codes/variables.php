<?php


//------------------------------------
// Openstack Authentication Attributes
//------------------------------------
//$controller_public_ip = "192.168.7.65"; 
//$controller_local_ip = "192.168.7.65";
$AdminURL = "http://192.168.7.65:5000/v2.0/tokens"; 
//------------------------------------
// Openstack Authentication Attributes
//------------------------------------
$ops_tenant 		= "aktiwa";
$ops_admin		= "aktiwa";
$ops_pass		= "12345";

//-----------------------------------------
// Openstack Services' Names as seen from Keystone
//-----------------------------------------
$identityService = "keystone";
$computeService = "nova";
$networkService = "neutron";


//------------------------------------------------
// Openstack External Networking Details
//-----------------------------------------------

$router_name = 'final-router' ; 
$ext_net = 'external-net';
//$ext_subnet_name = 'external-subnet';
//$ext_subnet = '192.168.7.0/24';
//$ext_dns = '192.168.7.253';
//$ext_gateway = '192.168.7.253';
//$floating_start = '192.168.7.120';
//$floating_end = '192.168.7.220';
$zone = 'nova';
$key_name = 'instance2';

$imgID = '04845bf9-7aae-4edb-9f5d-03944aa17c8d' ;// Ubuntu 14.04.4 LTS (Trusty Tahr) 
$flvID = '1CPU.2GBRAM.10GBDisk';//'1CPU.1GBRAM.5GBDisk';


//----------------------------
// Admin sFlow Monitoring Details
//---------------------------
$sflowServer = '192.168.7.65';
$sflowPort = '8008';
//for more metrics separate them by comma (,) with no spaces between them
//$metric = 'avg:vir_cpu_utilization';
?>
