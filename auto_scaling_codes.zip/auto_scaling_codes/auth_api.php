<?php


require 'variables.php';
echo 'From file auth_api'."\r\n\n";
//-----------------------------------
// 1. Get a Token using Openstack API
//-----------------------------------
if(!function_exists(os_request)){
function os_request($service, $request, $requestType) {
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_VERBOSE, false);
	curl_setopt($ch, CURLOPT_URL, $service);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $requestType);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $request);

	curl_setopt($ch, CURLOPT_HTTPHEADER, array(
				'Content-Type: application/json'));

	$result = curl_exec($ch);
	$result = json_decode($result);
	curl_close($ch);
	return $result;
}
}
//----------------------------------
// 2. Get the URL of a Service
//----------------------------------
if(!function_exists(getServiceURL)){
function getServiceURL($result, $service){
	$serviceURL = array();
	foreach($result->access->serviceCatalog as $endpoint){
		//print_r($endpoint);
		if ($endpoint->name == $service){
			$serviceURL = $endpoint->endpoints[0]->publicURL;
		}

	}
	return $serviceURL;
}
}
//==================
// Main Program
//==================


//-------------------------------
// Authentication Array
//-------------------------------
$data = array(
	'auth' => array(
		'tenantName' => $ops_tenant,
		'passwordCredentials' => array(
			'username' => $ops_admin,
			'password' => $ops_pass,
		),
	),
);


// convert the array to json
$data_string = json_encode($data);
//echo ($data_string)."\r\n";
//-------------------------------
// Request a Token
//-------------------------------
$auth = os_request($AdminURL, $data_string, "POST");

//--------------------------------------
// Identify the token of each connection
//--------------------------------------
$token = $auth->access->token->id;


//--------------------------------------
// Specify the URL of each Service
//--------------------------------------
$identityServiceURL = getServiceURL($auth, $identityService);
$computeServiceURL = getServiceURL($auth, $computeService);
$networkServiceURL = getServiceURL($auth, $networkService);


//echo '<br>'.$identityServiceURL."\r\n";
//echo '<br>'.$computeServiceURL."\r\n";
//echo '<br>'.$networkServiceURL."\r\n";

?>
