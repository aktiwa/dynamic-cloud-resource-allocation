<?php
//$i = 0;

while ($i<=300)
{

include 'launching_instance_from_snapshot.php';
 //       echo "i=$i ";
      //  sleep(5); sleep wont work under while because of set time 
//include 'sFlowRT.php';   
     $i++;
}
?>
