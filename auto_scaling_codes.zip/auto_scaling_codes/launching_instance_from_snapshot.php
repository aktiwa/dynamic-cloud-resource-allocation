
<?php


echo 'from main file'."\r\n";
require 'auth_api.php';


//-----------------------------
// 4. List Servers
//-----------------------------
if(!function_exists(get_server_id)){
function get_server_id($token, $service,$vm_ip_add){

  $server_IDx ='';
  $service = "$service/servers/detail";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_VERBOSE, false);
  curl_setopt($ch, CURLOPT_URL, $service);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_HTTPHEADER, array(
          'X-Auth-Token: ' . $token
      )
  );
  $result = curl_exec($ch);
  $servers = json_decode($result);
  curl_close($ch);
  foreach ($servers->servers as $server){
    $intnet = 'final.net';
    $add = $server->addresses->$intnet;
    foreach ($add as $ads){
      if ($ads->addr == $vm_ip_add){
        $server_IDx = $server->id;
        $server_Namx = $server->name;
      }
    }
  }
  return array($server_Namx, $server_IDx);
}
}//if closer

//-----------------------------
// 1. List sflow metrics
//-----------------------------

if(!function_exists(get_mem_utl_host)){

function get_mem_utl_host($service, $host, $metric){
  $service = $service."/$host/$metric/json";
  //echo '<br>'.$service.'<br>';
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_VERBOSE, false);
  curl_setopt($ch, CURLOPT_URL, $service);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_HTTPHEADER, array(
  //        'X-Auth-Token: ' . $token
      )
  );
  $result = curl_exec($ch);
  $networks = json_decode($result);
  curl_close($ch);
  return $networks;
}
}
//-----------------------------
// Main Program
//-----------------------------

for($xd = 0; $xd < 100; $xd++){


$link1 = 'http://192.168.7.65:8008/metric';

//next two line is related getting data for node 30.30.1.9/floating ip can be used instead also 
$server_ip_add = '30.30.1.57';
list($vm_name, $vm_id) = get_server_id($token, $computeServiceURL, $server_ip_add);
echo($vm_id);
echo ' ';
echo($vm_name)."\r\n";

$server_id = $vm_id;
$metric = "mem_utilization";//"cpu_utilization";
$x = 0;
$snapshot_name = 'snapshot.of.'.$vm_name;
$zone = 'nova';
$key_name = 'instance2';
$int_net = 'final.net';


$metrName = $metrValue = array();

$mem_utl = get_mem_utl_host($link1, $server_ip_add, $metric);


foreach($mem_utl as $singlemetr){
  $metrName[$x] = $singlemetr->metricName;
  $metrValue[$x] = $singlemetr->metricValue;
  $x++;
}

  $fd = 0;

foreach($metrName as $singlemet){
//printing metric name and its value got from sflowRT
  echo "<br>$metrName[$fd] = $metrValue[$fd]"."\r\n\n";
  if($metrName[$fd]=='mem_utilization' && $metrValue[$fd] >= 20){


       // Horizontal Scaling
        echo 'Memory util high, Horizontal scaling in process: '."\r\n\n";
        include 'snapshot_creation.php';
     	include 'srv_creation.php';
	  sleep(15);
      }
  
//else if ($metrName[$fd]=='mem_utilization' && $metrValue[$fd] <= 7){
//echo 'Memory utilization is lower than  7%'."\r\n\n";

//include 'termination.php';
//sleep(5);

//}
//if ($metrName[$fd]=='mem_utilization' && $metrValue[$fd] <= 10){
//echo 'Memory utilization is lower than  7%'."\r\n\n";
//sleep(5);
//} 


if ($metrName[$fd]=='mem_utilization' && $metrValue[$fd] <= 17){
include 'termination.php';
sleep(5);

}

}//first for
}//for loop

?>
