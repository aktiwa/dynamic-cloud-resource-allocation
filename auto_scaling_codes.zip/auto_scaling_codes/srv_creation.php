<?PHP

$comService = $computeServiceURL;
$netService = $networkServiceURL.'/v2.0';

echo 'from file srv_creation.php'.$comService."\r\n\n";


//-----------------------------
// 1. List Networks
//-----------------------------
if(!function_exists(list_networks)){
function list_networks($token, $service){
  $service = $service."/networks";
  //echo '<br>'. $service;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_VERBOSE, false);
  curl_setopt($ch, CURLOPT_URL, $service);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_HTTPHEADER, array(
          'X-Auth-Token: ' . $token
      )
  );
  $result = curl_exec($ch);
  $networks = json_decode($result);
  curl_close($ch);
  return $networks;
}
}
//----------------------------------------
// 2. Get External Network ID and Subnet ID
//----------------------------------------
if(!function_exists(get_net_id)){
function get_net_id($token, $service, $networks, $ext_net, $int_net){
  $ext_netID = $int_netID = "";
  foreach ($networks->networks as $network){
    if ($network->name == $ext_net) {
      $ext_netID = $network->id;
    }elseif ($network->name == $int_net){
      $int_netID = $network->id;
    }
  }

  return array($ext_netID, $int_netID);

}
}
//-----------------------------
// 3. Create Servers
//-----------------------------
if(!function_exists(create_servers)){
function create_servers($token, $service, $server_name, $imgID, $flvID, $netID,
                $zone, $key_name){
  $com_serv = $service;
  $service = $service."/servers";
  $data = array (
    'server' => array(
      'name' => $server_name,
      'imageRef' => $imgID,
      'flavorRef' => $flvID,
      'key_name' => $key_name,
      'availability_zone' => $zone,
      'networks' => [array(
        'uuid' => "$netID",
      )],
      'security_groups' => [array(
        'name' => 'default',
      )],
    ),
  );
  $data_string = json_encode($data);
echo ($data_string)."\r\n\n";

  $ch = curl_init();
  curl_setopt($ch, CURLOPT_VERBOSE, false);
  curl_setopt($ch, CURLOPT_URL, $service);
  curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
  curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json',
        'X-Auth-Token: ' . $token,
      ));

  $result = curl_exec($ch);
  $result = json_decode($result);
//  echo ($result);
  curl_close($ch);
 return $result;

}
}
//---------------------------------
// Main Program
//---------------------------------

$chk_srv='snapshot.of.'.$vm_name;
$imgID = $imgid;



    $server_name = $chk_srv;

    $networks = list_networks($token, $netService);
    list($ext_netID, $int_netID) = get_net_id($token, $netService, $networks,
                          $ext_net, $int_net);

  $server_id = create_servers($token, $comService, $server_name, $imgID, $flvID, $int_netID, $zone, $key_name);
 $serverID = $server_id->server->id;
echo ($serverID)."\r\n\n";
sleep(5);

?>
