<?php




require 'auth_api.php';


//-----------------------------
// 4. List Servers
//-----------------------------
function get_server_id($token, $service,$vm_ip_add){

  $server_IDx ='';
  $service = "$service/servers/detail";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_VERBOSE, false);
  curl_setopt($ch, CURLOPT_URL, $service);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_HTTPHEADER, array(
          'X-Auth-Token: ' . $token
      )
  );
  $result = curl_exec($ch);
  $servers = json_decode($result);
  curl_close($ch);
  foreach ($servers->servers as $server){
    $intnet = 'final.net';
    $add = $server->addresses->$intnet;
    foreach ($add as $ads){
      if ($ads->addr == $vm_ip_add){
        $server_IDx = $server->id;
        $server_Namx = $server->name;
      }
    }
  }
  return array($server_Namx, $server_IDx);
}

//-----------------------------
// 1. List sflow metrics
//-----------------------------
function get_mem_utl_host($service, $host, $metric){
  $service = $service."/$host/$metric/json";
  //echo '<br>'.$service.'<br>';
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_VERBOSE, false);
  curl_setopt($ch, CURLOPT_URL, $service);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_HTTPHEADER, array(
  //        'X-Auth-Token: ' . $token
      )
  );
  $result = curl_exec($ch);
echo ($result )."\r\n";
  $networks = json_decode($result);
  curl_close($ch);
  return $networks;
}

//-----------------------------
// Main Program
//-----------------------------
$link1 = 'http://192.168.7.65:8008/metric';

//next two line is related getting data for node 192.168.7.173/30.30.1.6 
$server_ip_add = '192.168.7.173';
list($vm_name, $vm_id) = get_server_id($token, $computeServiceURL, $server_ip_add);
echo($vm_id);
echo ' ';
echo($vm_name)."\r\n";

$server_id = $vm_id;
$metric = "cpu_utilization";

$mem_utl = get_mem_utl_host($link1, $server_ip_add, $metric);
$memo= json_encode($mem_util);
echo($memo)."\r\n";
?>
