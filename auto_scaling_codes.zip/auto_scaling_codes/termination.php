
<?php



echo 'From termination file:'."\r\n";

//-----------------------------
// 4. List Servers
//-----------------------------
if(!function_exists(get_srv_id)){

function get_srv_id($token, $service,$vm_ip_add){

  $server_IDx ='';
  $service = "$service/servers/detail";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_VERBOSE, false);
  curl_setopt($ch, CURLOPT_URL, $service);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_HTTPHEADER, array(
          'X-Auth-Token: ' . $token
      )
  );
  $result = curl_exec($ch);
  $servers = json_decode($result);
  curl_close($ch);
  foreach ($servers->servers as $server){
    $intnet = 'final.net';
    $add = $server->addresses->$intnet;
    foreach ($add as $ads){
      if ($ads->addr == $vm_ip_add){
        $server_IDx = $server->id;
        $server_Namx = $server->name;
      }
    }
  }
  return array($server_Namx, $server_IDx);
}
}

//-----------------------------
// 1. List Networks
//-----------------------------
if(!function_exists(check_img)){
function check_img($token, $service, $name){
  $service = "$service/images/detail";
  $imgstatus = '';
  //echo '<br>'. $service;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_VERBOSE, false);
  curl_setopt($ch, CURLOPT_URL, $service);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_HTTPHEADER, array(
          'X-Auth-Token: ' . $token
      )
  );
  $result = curl_exec($ch);
  $result = json_decode($result);
  curl_close($ch);

  foreach ($result->images as $image){
    if ($image->name == $name){
      $imgstatus = $image->status;
    }

  }
  return $imgstatus;
}
}

// 3. Delete Servers
//-----------------------------
if(!function_exists(del_servers)){
function del_servers($computeServiceURL, $serverID, $token){
  $servicex ='/servers';
 $service = $computeServiceURL.$servicex;
 $service = $service."/$serverID";
 // $service = $service.'/servers'."/$server_id/";

  $ch = curl_init();
  curl_setopt($ch, CURLOPT_VERBOSE, false);
  curl_setopt($ch, CURLOPT_URL, $service);
  curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_HTTPHEADER, array(
          'X-Auth-Token: ' . $token,
      )
  );
  $result = curl_exec($ch);
  $del_serv = json_decode($result);
  curl_close($ch);
  return $del_serv;
}
}
//-----------------------------
// Main Program
//-----------------------------


//next two line is related getting data for node ip, floating ip can be used instead also 

$server_ip_add2 = '30.30.1.111';
$server_ip_add = '30.30.1.110';
$server_ip_add1 = '30.30.1.109';

list($vm_name2, $vm_id2) = get_srv_id($token, $computeServiceURL, $server_ip_add2);
echo($vm_id)."\r\n\n";
echo ' ';
$imgstatus = check_img($token, $computeServiceURL, $vm_name2);
if($imgstatus == 'ACTIVE'){
   
        echo ("memory_util below 7%")."\r\n";
        echo 'server in deletion :'.$vm_name2." ".$vm_id2."\r\n";
 
        del_servers($computeServiceURL, $vm_id2, $token);
        sleep(2);
                 }


list($vm_name, $vm_id) = get_srv_id($token, $computeServiceURL, $server_ip_add);
echo($vm_id)."\r\n\n";
echo ' ';
$imgstatus = check_img($token, $computeServiceURL, $vm_name);
if($imgstatus == 'ACTIVE'){
   
	echo ("memory_util below 7%")."\r\n";
	echo 'server in deletion :'.$vm_name." ".$vm_id."\r\n";
 
	del_servers($computeServiceURL, $vm_id, $token);
	sleep(2);
		 }

list($vm_name1, $vm_id1) = get_srv_id($token, $computeServiceURL, $server_ip_add1);
echo($vm_id1)."\r\n\n";
echo ' ';
$imgstatus1 = check_img($token, $computeServiceURL, $vm_name1);
if($imgstatus1 == 'ACTIVE'){
   
	echo ("memory_util below 7%")."\r\n";
	echo 'server in deletion :'.$vm_name1." ".$vm_id1."\r\n";
 
 	del_servers($computeServiceURL, $vm_id1, $token);
sleep(2); 		
	 }


else{
echo ("memory_util below 7%")."\r\n";
}


?>
