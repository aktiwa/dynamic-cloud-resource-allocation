<?php

// increase the maximum execution time to 43200 seconds (12 hours)
set_time_limit(43200);

function runTask() {
    static $cycles = 0;

    // do whatever you need to do
 include 'launching_instance_from_snapshot.php';
    // Increments cycle count then compares against limit
    if ($cycles++ < 180)  {
        sleep(5);  // wait five seconds
        runTask(); // run it again
    }
}

runTask();
