<?php

echo 'From file snapshot_creation'."\r\n\n";

//-----------------------------
// 1. List Networks
//-----------------------------
if(!function_exists(check_images)){
function check_images($token, $service, $name){
  $service = "$service/images/detail";
  $imgstatus = '';
  //echo '<br>'. $service;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_VERBOSE, false);
  curl_setopt($ch, CURLOPT_URL, $service);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_HTTPHEADER, array(
          'X-Auth-Token: ' . $token
      )
  );
  $result = curl_exec($ch);
  $result = json_decode($result);
  curl_close($ch);

  foreach ($result->images as $image){
    if ($image->name == $name){
      $imgstatus = $image->status;
      $imgid = $image->id;
    }

  }
  return array($imgstatus, $imgid);
}
}

//-----------------------------
// 2. create a flavor
//-----------------------------
if(!function_exists(create_snapshot)){
function create_snapshot($token, $service, $name, $server_id){

  $service = "$service/servers/$server_id/action";
  //echo "<br> $service <br> ";

  $data = array (
    'createImage' => array(
      'name' => $name,
      'metadata' => array(
        'instance_uuid' => $server_id,
      ),
    ),
  );

  $data_string = json_encode($data);
 echo ($data_string)."\r\n\n";

  $ch = curl_init();
  curl_setopt($ch, CURLOPT_VERBOSE, false);
  curl_setopt($ch, CURLOPT_URL, $service);
  curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
  curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json',
        'X-Auth-Token: ' . $token,
      ));

  $result = curl_exec($ch);
  $result = json_decode($result);

  curl_close($ch);

  return $result;

}
}

//-----------------------------
// Main Program
//-----------------------------

$cr_snap = create_snapshot($token, $computeServiceURL, $snapshot_name, $vm_id);

for ($i=0; $i<1000; $i++){
  list($imgstatus, $imgid) = check_images($token, $computeServiceURL, $snapshot_name);
 if($imgstatus == 'ACTIVE'){
 sleep(2); 
 break;
  }
}

?>
